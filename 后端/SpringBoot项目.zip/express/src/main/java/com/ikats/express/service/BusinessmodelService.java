package com.ikats.express.service;

import com.ikats.common.exception.InvokerResult;


public interface BusinessmodelService {


    InvokerResult selectBase();

}
