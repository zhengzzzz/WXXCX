package com.ikats.common.constants;

/**
 * @author shnejian26@hotmail.com
 * @date 2018/12/3 17:46
 */

public class Constants {


}